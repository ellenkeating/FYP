
//I created this class in an attempt to implement the RecyclerView to view data of my adverts
//I was unable to implement this feature in this iteration
//I took this code from a lab example that I did as a part of my Mobile Application Development module, and the code was written by Michael Gleeson, the module lecturer


/*
 *   Created By Michael Gleeson on 10/10/2018
 *   Copyright (c) 2018 | gleeson.io
 */


package com.ebk.fypv1;

//imports necessary for android features
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;


public class AdvertsAdapter extends RecyclerView.Adapter<AdvertsAdapter.MyViewHolder> {

    private Context context;
    private List<Advert> advertList;

    public class MyViewHolder extends RecyclerView.ViewHolder {

        public TextView advertName, advertCategory, advertId;

        public MyViewHolder(View view){
            super(view);

            advertName = view.findViewById(R.id.tvName);
            advertCategory = view.findViewById(R.id.tvCat);
            advertId = view.findViewById(R.id.tvId);
        }
    }

    public AdvertsAdapter(Context context, List<Advert> advertList) {

        this.context = context;
        this.advertList = advertList;
    }

    //get rid of NonNull?
    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
     View itemView = LayoutInflater.from(parent.getContext())
             .inflate(R.layout.advert_list_row, parent, false);

     return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder (MyViewHolder holder, int position) {
        Advert advert = advertList.get(position);

        holder.advertName.setText(advert.getAdvertName());
        holder.advertCategory.setText(advert.getAdvertCategory());
        holder.advertId.setText(advert.getAdvertId() + "");

    }

    public int getItemCount() {
        return advertList.size();
    }
}
