package com.ebk.fypv1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class EditAdvert extends AppCompatActivity {


    DatabaseHelper myDb;
    EditText etEditAdvertId, etEditAdvertName, etEditAdvertDescription, etEditAdvertImage, etEditAdvertUserID, etEditAdvertCategory;
    Button btnUpdateAdvert , btnEditBack;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_advert);

        myDb = new DatabaseHelper(this);

        etEditAdvertId = findViewById(R.id.etEditAdvertID);
        etEditAdvertName = findViewById(R.id.etEditAdvertName);
        etEditAdvertDescription = findViewById(R.id.etEditAdvertDescription);
        etEditAdvertImage = findViewById(R.id.etEditAdvertImage);
        etEditAdvertUserID = findViewById(R.id.etEditAdvertUserID);
        etEditAdvertCategory = findViewById(R.id.etEditAdvertCategory);
        btnUpdateAdvert = findViewById(R.id.btnUpdateAdvert);
        btnEditBack = findViewById(R.id.btnEditBack);
        updateData();

        btnEditBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent (EditAdvert.this, CreateAdvert.class);
                startActivity(intent);
            }
        });
    }

    //calls updateData method in DatabaseHelper class
    public void updateData(){

        btnUpdateAdvert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //check if data is updated
               boolean isUpdated = myDb.updateData(etEditAdvertId.getText().toString(), etEditAdvertName.getText().toString(), etEditAdvertDescription.getText().toString(),
                       etEditAdvertImage.getText().toString() , Integer.parseInt(etEditAdvertUserID.getText().toString()) , etEditAdvertCategory.getText().toString());

               if (isUpdated == true) {
                   Toast.makeText(EditAdvert.this, "Data Updated", Toast.LENGTH_LONG).show();
               } else {
                   Toast.makeText(EditAdvert.this, "Data Not Updated", Toast.LENGTH_LONG).show();

               }
            }
        });
    }


}
