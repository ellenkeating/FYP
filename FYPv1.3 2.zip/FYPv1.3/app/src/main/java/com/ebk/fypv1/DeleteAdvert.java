 package com.ebk.fypv1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

 public class DeleteAdvert extends AppCompatActivity {

     DatabaseHelper myDb;
     EditText etDeleteId;
    Button btnDeleteAdvert,btnDeleteBack;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_advert);

        myDb = new DatabaseHelper(this);

        btnDeleteAdvert = findViewById(R.id.btnDeleteAdvert);
        btnDeleteBack = findViewById(R.id.btnDeleteBack);
        etDeleteId = findViewById(R.id.etDeleteAdvertId);
        deleteData();

        //Button to go back to back to manage advert
        btnDeleteBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent (DeleteAdvert.this, CreateAdvert.class);
                startActivity(intent);
            }
        });

    }

    //method to delete data, calls DeleteAdvert method in DatabaseHelper
    public void deleteData(){

        btnDeleteAdvert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Integer deletedRows = myDb.deleteData(etDeleteId.getText().toString());

                if (deletedRows > 0) {
                    Toast.makeText(DeleteAdvert.this, "Data Deleted", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(DeleteAdvert.this, "Data Not Deleted", Toast.LENGTH_LONG).show();

                }
            }
        });
    }
}
