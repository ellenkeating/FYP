package com.ebk.fypv1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    private Button btnViewCreateAdvert, btnBrowseAdverts;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        //button to go to CreateAdvert activity
        btnViewCreateAdvert = (Button) findViewById(R.id.btnViewCreateAdvert);

        btnViewCreateAdvert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent (MainActivity.this, CreateAdvert.class);
                startActivity(intent);
            }
        });

        //Button currently hidden as I do not have the browse adverts feature implemented yet.
        btnBrowseAdverts = (Button) findViewById(R.id.btnBrowseAdverts);

        btnBrowseAdverts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent (MainActivity.this, BrowseAdverts.class);
                startActivity(intent);
            }
        });
    }
}
