//I created this class in an attempt to implement the RecyclerView to view data of my adverts
//I was unable to implement this feature in this iteration
//I took this code from a lab example that I did as a part of my Mobile Application Development module, and the code was written by Michael Gleeson, the module lecturer

package com.ebk.fypv1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

public class BrowseAdverts extends AppCompatActivity {

    //Instance of the database helper class
    private DatabaseHelper myDb;

    private AdvertsAdapter mAdapter;
    private List<Advert> advertsList = new ArrayList<>();
    private CoordinatorLayout coordinatorLayout;
    private TextView noAdvertsView;
    private RecyclerView recyclerView;
    //private TextView noNotesView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_browse_adverts);

        coordinatorLayout = findViewById(R.id.coordinator_layout);
        recyclerView = findViewById(R.id.rvBrowseAdverts);
        noAdvertsView = findViewById(R.id.tvNoAdverts);

        //Toolbar toolbar = findViewById(R.id.toolbar);
        //setSupportActionBar(toolbar);

        myDb = new DatabaseHelper(this);

        advertsList.addAll(myDb.getAllAdverts());

        mAdapter = new AdvertsAdapter(this, advertsList);
        RecyclerView.LayoutManager mLayoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(mLayoutManager);
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        //add a default divider line between items
        recyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));

        //below uses a custom divider item decoration from MyDividerItemDecoration Class
        //recyclerView.addItemDecoration(new MyDividerItemDecoration(this, LinearLayoutManager.VERTICAL, 16));
        recyclerView.setAdapter(mAdapter);

       toggleEmptyAdverts();

    }

    private void toggleEmptyAdverts() {
        // you can check notesList.size() > 0

        if (myDb.getAdvertCount() > 0) {
            noAdvertsView.setVisibility(View.GONE);
        } else {
            noAdvertsView.setVisibility(View.VISIBLE);
        }
    }


/*
    //Code from the View data method in CreateAccount.
    public void prepareAdvertData(){

        //cursor provides random read-write access to the result set returned by a database query
        Cursor result =  myDb.getAllData();

        StringBuffer buffer = new StringBuffer();
        //moves cursor to next result
        while (result.moveToNext()){

            //index of column, starts at 0 (Advert ID)
            String id = buffer.append(result.getString(0)).toString(); //ID
            String name = buffer.append(result.getString(1)).toString(); //Name
            String category = buffer.append(result.getString(5)).toString(); //Category

        }

      // Advert advert = new Advert("Hello" , "")

    }
    */
}
