package com.ebk.fypv1;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CreateAdvert extends AppCompatActivity {

    //instance of db class to create an instance of my database in this activity
    DatabaseHelper myDb;

    //declare my editText and Buttons
    EditText etAdvertName, etAdvertDescription, etAdvertImage, etAdvertUserID, etAdvertCategory;
    Button btnCreateAdvert, btnViewAdverts , btnUpdateAdvert , btnDeleteData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_advert);

        //new instance of my database
        myDb = new DatabaseHelper(this);

        //cast buttons and EditTexts to the variable
        etAdvertName = findViewById(R.id.etAdvertName);
        etAdvertDescription = findViewById(R.id.etAdvertDescription);
        etAdvertImage = findViewById(R.id.etAdvertImage);
        etAdvertUserID = findViewById(R.id.etAdvertUserID);
        etAdvertCategory = findViewById(R.id.etAdvertCategory);
        btnCreateAdvert = findViewById(R.id.btnCreateAdvert);
        btnViewAdverts = findViewById(R.id.btnViewAdverts);
        btnUpdateAdvert = findViewById(R.id.btnEditAdvert);

        //add method to on create method
        addAdvert();
        viewAdverts();

        //code to bring user to new activity on button click
        btnUpdateAdvert = (Button) findViewById(R.id.btnEditAdvert);

        btnUpdateAdvert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent (CreateAdvert.this, EditAdvert.class);
                startActivity(intent);
            }
        });

        btnDeleteData = (Button) findViewById(R.id.btnDeleteData);

        btnDeleteData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent (CreateAdvert.this, DeleteAdvert.class);
                startActivity(intent);
            }
        });


    }

    //method to add advert to database
    public void addAdvert() {
        //create advert in database on create account button click
        btnCreateAdvert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //boolean to check if the data was inserted successfully
               boolean isInserted  = myDb.insertData(etAdvertName.getText().toString(), etAdvertDescription.getText().toString(),
                       etAdvertImage.getText().toString() , Integer.parseInt(etAdvertUserID.getText().toString()) , etAdvertCategory.getText().toString());

              if (isInserted == true)
                  Toast.makeText(CreateAdvert.this, "Data Inserted", Toast.LENGTH_LONG).show();
                else
                  Toast.makeText(CreateAdvert.this, "Data Not Inserted", Toast.LENGTH_LONG).show();

            }
        });
    }

    //method to view adverts
    public void viewAdverts() {
        btnViewAdverts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              Cursor result =  myDb.getAllData();

              //if database is empty
              if (result.getCount() == 0) {

                  showMessage("Error", "No data found");
                  return;

              }

              //string buffer is method of storing string values
              StringBuffer buffer = new StringBuffer();
              //moves cursor to next result
                while (result.moveToNext()){

                  //index of column, starts at 0 (Advert ID)
                  buffer.append("id: " + result.getString(0) + "\n");
                  buffer.append("Title: " + result.getString(1) + "\n");
                  buffer.append("Description: " + result.getString(2) + "\n");
                  buffer.append("Image URL: " + result.getString(3) + "\n");
                  buffer.append("Advert User ID: " + result.getString(4) + "\n");
                  buffer.append("Advert Category: " + result.getString(5) + "\n");

              }
            //calls below method to show message using an alert dialog
            showMessage("Data" , buffer.toString());

            }
        });
    }

    public void showMessage(String title, String message){
        //build alert dialog to display data
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}
